import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Flight {
    private String flightNumber;
    private Aeroport departure;
    private Aeroport arrival;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;

    public Flight(String flightNumber, Aeroport departure, Aeroport arrival, String depTimeStr, String arrTimeStr) {
        this.flightNumber = flightNumber;
        this.departure = departure;
        this.arrival = arrival;

        // Formatage simplifié de la date (on coupe le "+00:00" à la fin si nécessaire)
        // Le format ISO standard est supporté par défaut par LocalDateTime
        try {
            this.departureTime = LocalDateTime.parse(depTimeStr.substring(0, 19));
            this.arrivalTime = LocalDateTime.parse(arrTimeStr.substring(0, 19));
        } catch (Exception e) {
            System.err.println("Erreur de date pour le vol " + flightNumber);
        }
    }

    @Override
    public String toString() {
        return "Vol " + flightNumber + " : " +
                (departure != null ? departure.getIata() : "???") + " -> " +
                (arrival != null ? arrival.getIata() : "???");
    }
}