import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class World {
    private ArrayList<Aeroport> list = new ArrayList<>();

    public World(String fileName) {
        // Chargement automatique depuis le dossier src
        InputStream is = getClass().getResourceAsStream(fileName);
        if (is == null) {
            System.err.println("Fichier introuvable : " + fileName);
            return;
        }
        loadAirports(is);
    }

    private void loadAirports(InputStream is) {
        // Regex complexe pour gérer les virgules DANS les guillemets
        String splitRegex = ",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)";

        try (BufferedReader br = new BufferedReader(new InputStreamReader(is))) {
            br.readLine(); // Sauter l'en-tête
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(splitRegex);

                // On sécurise pour éviter les lignes vides ou incomplètes
                if (data.length < 12) continue;

                // Optionnel : Filtrer pour ne garder que les gros aéroports (plus rapide)
                // if (!data[1].equals("large_airport")) continue;

                try {
                    String iata = data[9].replace("\"", ""); // Code IATA
                    String name = data[2].replace("\"", "");
                    String country = data[5].replace("\"", "");

                    // Gestion des coordonnées "lon, lat"
                    String coords = data[11].replace("\"", "");
                    String[] latLon = coords.split(",");

                    // Attention : le CSV est souvent en Longitude, Latitude
                    double lon = Double.parseDouble(latLon[0].trim());
                    double lat = Double.parseDouble(latLon[1].trim());

                    list.add(new Aeroport(iata, name, country, lat, lon));
                } catch (Exception e) {
                    // On ignore silencieusement les lignes qui plantent (souvent des formats bizarres)
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Méthode pour trouver un aéroport par son code IATA (nécessaire pour les vols)
    public Aeroport findByCode(String iataCode) {
        for (Aeroport a : list) {
            if (a.getIata().equals(iataCode)) {
                return a;
            }
        }
        return null;
    }

    public ArrayList<Aeroport> getList() { return list; }
}