import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws    Exception {
        // 1. Initialisation des données
        System.out.println("Chargement du monde...");
        World world = new World("airport-codes_no_comma.csv");

        // 2. Création de la Terre
        Earth earth = new Earth();

        // 3. Affichage des aéroports (Boules rouges)
        // Attention : si on affiche tout, ça peut ramer. On peut limiter.
        System.out.println("Génération des points 3D...");
        for (Aeroport a : world.getList()) {
            // Astuce : On n'affiche que les "large_airport" ou tout si ta machine tient le coup
            // Ici j'affiche tout ce que World a chargé
            earth.displayRedSphere(a);
        }

        // 4. Configuration de la Scène 3D
        Group root = new Group();
        root.getChildren().add(earth);

        Scene scene = new Scene(root, 800, 600, true); // true = buffer de profondeur (3D)

        // 5. Caméra
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setTranslateZ(-1000); // Reculer la caméra pour voir la Terre en entier
        camera.setNearClip(0.1);
        camera.setFarClip(2000.0);
        camera.setFieldOfView(35);
        scene.setCamera(camera);

        // 6. Lancement de la fenêtre
        primaryStage.setTitle("TP Java - Visualisation Vols");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}