import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class JsonFlightFiller {
    private ArrayList<Flight> flights = new ArrayList<>();

    public JsonFlightFiller(String jsonFileName, World world) {
        InputStream is = getClass().getResourceAsStream(jsonFileName);
        if (is == null) {
            System.err.println("Fichier JSON introuvable : " + jsonFileName);
            return;
        }

        try (JsonReader reader = Json.createReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            JsonObject root = reader.readObject();
            JsonArray data = root.getJsonArray("data");

            for (int i = 0; i < data.size(); i++) {
                JsonObject obj = data.getJsonObject(i);

                // On ne traite que les vols qui ont un statut (par sécurité)
                if (!obj.containsKey("flight_status")) continue;

                // Récupération des blocs
                JsonObject depObj = obj.getJsonObject("departure");
                JsonObject arrObj = obj.getJsonObject("arrival");
                JsonObject flightObj = obj.getJsonObject("flight");

                // Extraction des codes IATA
                String depIata = depObj.getString("iata");
                String arrIata = arrObj.getString("iata");
                String flightNum = flightObj.getString("number");

                // Dates
                String depTime = depObj.getString("scheduled");
                String arrTime = arrObj.getString("scheduled");

                // On cherche les vrais objets Aeroport dans le World
                Aeroport depAirport = world.findByCode(depIata);
                Aeroport arrAirport = world.findByCode(arrIata);

                // On ajoute le vol (même si un aéroport est null, on gère ça dans le toString pour l'instant)
                flights.add(new Flight(flightNum, depAirport, arrAirport, depTime, arrTime));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ArrayList<Flight> getFlights() { return flights; }
}