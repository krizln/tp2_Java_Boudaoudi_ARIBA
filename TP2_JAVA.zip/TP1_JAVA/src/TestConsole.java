public class TestConsole {
    public static void main(String[] args) {
        System.out.println("--- Chargement du Monde ---");
        World w = new World("airport-codes_no_comma.csv");
        System.out.println("Aéroports trouvés : " + w.getList().size());

        System.out.println("\n--- Chargement des Vols ---");
        // Utilise bien le nom de ton nouveau fichier .json
        JsonFlightFiller filler = new JsonFlightFiller("Interrogation sur orly.json", w);
        System.out.println("Vols récupérés : " + filler.getFlights().size());

        // Affichage des 5 premiers vols pour vérifier
        for(int i=0; i<Math.min(5, filler.getFlights().size()); i++) {
            System.out.println(filler.getFlights().get(i));
        }
    }
}