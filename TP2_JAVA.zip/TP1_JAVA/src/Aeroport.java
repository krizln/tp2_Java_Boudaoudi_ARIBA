public class Aeroport {
    private String iata;
    private String name;
    private String country;
    private double latitude;
    private double longitude;

    public Aeroport(String iata, String name, String country, double latitude, double longitude) {
        this.iata = iata;
        this.name = name;
        this.country = country;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public String getIata() { return iata; }
    public double getLatitude() { return latitude; }
    public double getLongitude() { return longitude; }

    @Override
    public String toString() {
        return "Aeroport{" + iata + " (" + country + ") " + latitude + ", " + longitude + "}";
    }
}