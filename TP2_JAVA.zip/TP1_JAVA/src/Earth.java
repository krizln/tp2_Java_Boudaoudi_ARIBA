import javafx.animation.AnimationTimer;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.paint.PhongMaterial;
import javafx.scene.shape.Sphere;
import javafx.scene.transform.Rotate;
import javafx.scene.image.Image;

import java.util.ArrayList;

public class Earth extends Group {

    private Sphere sph;
    private ArrayList<Sphere> yellowSpheres;
    private Rotate ry;

    public Earth() {
        // 1. Création de la sphère Terre (Rayon 300 comme demandé)
        sph = new Sphere(300);

        // 2. Application de la texture (l'image de la carte du monde)
        PhongMaterial material = new PhongMaterial();
        try {
            // Attention : l'image doit être dans le dossier src
            Image texture = new Image(getClass().getResourceAsStream("image_ad4b04.jpg"));
            material.setDiffuseMap(texture);
        } catch (Exception e) {
            System.err.println("Impossible de charger la texture de la terre !");
            material.setDiffuseColor(Color.BLUE); // Bleu par défaut si image absente
        }
        sph.setMaterial(material);

        // 3. Configuration de la rotation
        ry = new Rotate(0, Rotate.Y_AXIS);
        sph.getTransforms().add(ry);

        // 4. Ajout de la sphère au groupe (this)
        this.getChildren().add(sph);

        // 5. Lancer l'animation de rotation (optionnel, fait tourner la terre)
        AnimationTimer animation = new AnimationTimer() {
            @Override
            public void handle(long now) {
                // Tourne de 0.1 degré par frame
                ry.setAngle(ry.getAngle() + 0.1);
            }
        };
        animation.start();
    }

    public Sphere createSphere(Aeroport a, Color color) {
        // Conversion Coordonnées Sphériques (Lat/Lon) -> Cartésiennes (X/Y/Z)
        // Rayon de la terre (300) + un tout petit peu (2) pour que le point soit au dessus
        double R = 300 + 2;

        // Mathématiques : Conversion degrés -> radians
        double lat = Math.toRadians(a.getLatitude());
        double lon = Math.toRadians(a.getLongitude());

        // Formules classiques de projection sphérique
        // Note: L'axe Y est inversé en JavaFX (vers le bas), d'où le signe moins sur Y
        double x = R * Math.cos(lat) * Math.sin(lon);
        double y = -R * Math.sin(lat);
        double z = -R * Math.cos(lat) * Math.cos(lon);

        Sphere s = new Sphere(2); // Petite sphère de rayon 2 pour l'aéroport
        s.setMaterial(new PhongMaterial(color));
        s.setTranslateX(x);
        s.setTranslateY(y);
        s.setTranslateZ(z);

        return s;
    }

    public void displayRedSphere(Aeroport a) {
        Sphere s = createSphere(a, Color.RED);
        this.getChildren().add(s);
    }
}